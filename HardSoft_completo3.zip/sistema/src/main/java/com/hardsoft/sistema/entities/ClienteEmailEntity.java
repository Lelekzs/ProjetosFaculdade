package com.hardsoft.sistema.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Email de um cliente. 1 cliente pode ter N emails.
 * Exatamente 1 deve ser marcado como principal=true.
 */
@Entity
@Table(name = "tb_cliente_emails")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteEmailEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEmail;

    @Column(nullable = false, length = 100)
    private String email;

    @Column(nullable = false)
    private Boolean principal = false;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_cliente")
    @JsonIgnore
    private ClienteEntity cliente;
}
