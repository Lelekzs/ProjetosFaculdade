package com.hardsoft.sistema.dtos;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO para criar/editar cliente.
 * Cliente nao loga no sistema, mas precisa ter pelo menos 1 email e 1 telefone
 * para contato (com um deles marcado como principal em cada lista).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteRequestDTO {

    @NotBlank(message = "Nome e obrigatorio")
    @Size(max = 100)
    private String nome;

    @NotBlank(message = "CPF/CNPJ e obrigatorio")
    @Pattern(regexp = "\\d{11}|\\d{14}",
             message = "CPF deve ter 11 digitos ou CNPJ deve ter 14 (apenas numeros)")
    private String cpfCnpj;

    @Size(max = 20)
    private String rg;

    @NotBlank(message = "Endereco e obrigatorio")
    @Size(max = 200)
    private String endereco;

    @NotEmpty(message = "Informe pelo menos um email")
    @Valid
    private List<ClienteEmailDTO> emails;

    @NotEmpty(message = "Informe pelo menos um telefone")
    @Valid
    private List<ClienteTelefoneDTO> telefones;
}
