package com.hardsoft.sistema.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Telefone de um cliente. 1 cliente pode ter N telefones.
 * Exatamente 1 deve ser marcado como principal=true.
 */
@Entity
@Table(name = "tb_cliente_telefones")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteTelefoneEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTelefone;

    @Column(nullable = false, length = 20)
    private String telefone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TipoTelefone tipo;

    @Column(nullable = false)
    private Boolean principal = false;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_cliente")
    @JsonIgnore
    private ClienteEntity cliente;
}
