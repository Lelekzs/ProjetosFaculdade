package com.hardsoft.sistema.entities;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe base de qualquer usuario do sistema.
 * Admin e Cliente herdam desta classe (estrategia JOINED:
 * gera uma tabela tb_usuarios + uma tabela por subclasse).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tb_usuarios")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class UsuarioEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    /**
     * Email — opcional na base. Obrigatorio apenas para Admins (que fazem login).
     * Unicidade e validada no AdminService (no banco nao tem @unique pra permitir
     * varios NULLs em clientes que nao tem email).
     */
    @Column(length = 100)
    private String email;

    /**
     * Senha — opcional na base. Obrigatoria apenas para Admins.
     * 60 chars pra caber um hash BCrypt (quando adicionar Spring Security).
     */
    @Column(length = 60)
    private String senha;

    @Column(length = 20)
    private String telefone;

    @Column(length = 200)
    private String endereco;

    @Column(name = "data_cadastro", nullable = false)
    private LocalDate dataCadastro;

    @PrePersist
    protected void onCreate() {
        if (this.dataCadastro == null) {
            this.dataCadastro = LocalDate.now();
        }
    }
}
