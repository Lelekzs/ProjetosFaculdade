package com.hardsoft.sistema.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hardsoft.sistema.dtos.LoginRequestDTO;
import com.hardsoft.sistema.dtos.LoginResponseDTO;
import com.hardsoft.sistema.entities.AdminEntity;
import com.hardsoft.sistema.exceptions.BusinessException;
import com.hardsoft.sistema.repositories.AdminRepository;

/**
 * Autenticacao simples: confere email + senha contra a tabela de admins.
 * Versao academica - sem token, sem Spring Security, senha em texto puro.
 */
@Service
public class AuthService {

    @Autowired
    private AdminRepository adminRepository;

    public LoginResponseDTO login(LoginRequestDTO dto) {
        // buscar admin pelo email
        AdminEntity admin = adminRepository.findByEmail(dto.getEmail())
            .orElseThrow(() -> new BusinessException("Email ou senha invalidos."));

        // conferir a senha (texto puro, comparacao direta)
        if (admin.getSenha() == null || !admin.getSenha().equals(dto.getSenha())) {
            throw new BusinessException("Email ou senha invalidos.");
        }

        // login OK - devolve os dados (sem a senha)
        return LoginResponseDTO.fromEntity(admin);
    }
}
