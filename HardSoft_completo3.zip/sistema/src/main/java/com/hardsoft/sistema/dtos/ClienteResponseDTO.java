package com.hardsoft.sistema.dtos;

import java.time.LocalDate;
import java.util.List;

import com.hardsoft.sistema.entities.ClienteEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteResponseDTO {

    private Long id;
    private String nome;
    private String cpfCnpj;
    private String rg;
    private String endereco;
    private LocalDate dataCadastro;

    private List<ClienteEmailDTO> emails;
    private List<ClienteTelefoneDTO> telefones;

    /** Email marcado como principal (atalho pra exibicao rapida). */
    private String emailPrincipal;
    /** Telefone marcado como principal (atalho pra exibicao rapida). */
    private String telefonePrincipal;

    public static ClienteResponseDTO fromEntity(ClienteEntity c) {
        List<ClienteEmailDTO> emails = c.getEmails().stream()
            .map(e -> new ClienteEmailDTO(e.getIdEmail(), e.getEmail(), e.getPrincipal()))
            .toList();

        List<ClienteTelefoneDTO> telefones = c.getTelefones().stream()
            .map(t -> new ClienteTelefoneDTO(t.getIdTelefone(), t.getTelefone(), t.getTipo(), t.getPrincipal()))
            .toList();

        String emailPrincipal = emails.stream()
            .filter(ClienteEmailDTO::getPrincipal)
            .map(ClienteEmailDTO::getEmail)
            .findFirst().orElse(null);

        String telefonePrincipal = telefones.stream()
            .filter(ClienteTelefoneDTO::getPrincipal)
            .map(ClienteTelefoneDTO::getTelefone)
            .findFirst().orElse(null);

        return new ClienteResponseDTO(
            c.getId(),
            c.getNome(),
            c.getCpfCnpj(),
            c.getRg(),
            c.getEndereco(),
            c.getDataCadastro(),
            emails,
            telefones,
            emailPrincipal,
            telefonePrincipal
        );
    }
}
