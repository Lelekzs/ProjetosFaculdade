package com.hardsoft.sistema.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hardsoft.sistema.dtos.ClienteEmailDTO;
import com.hardsoft.sistema.dtos.ClienteRequestDTO;
import com.hardsoft.sistema.dtos.ClienteResponseDTO;
import com.hardsoft.sistema.dtos.ClienteTelefoneDTO;
import com.hardsoft.sistema.entities.ClienteEmailEntity;
import com.hardsoft.sistema.entities.ClienteEntity;
import com.hardsoft.sistema.entities.ClienteTelefoneEntity;
import com.hardsoft.sistema.exceptions.BusinessException;
import com.hardsoft.sistema.exceptions.ResourceNotFoundException;
import com.hardsoft.sistema.repositories.ClienteRepository;
import com.hardsoft.sistema.repositories.OrdemServicoRepository;
import com.hardsoft.sistema.repositories.SetupRepository;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository repository;

    @Autowired
    private OrdemServicoRepository ordemServicoRepository;

    @Autowired
    private SetupRepository setupRepository;

    private static final List<String> STATUS_FINALIZADOS = List.of("CONCLUIDA", "ENTREGUE");

    @Transactional(readOnly = true)
    public List<ClienteResponseDTO> listarTodos() {
        // Retorna apenas clientes ATIVOS (os inativados por soft delete ficam ocultos)
        return repository.findByStatusClienteIgnoreCase("ATIVO").stream()
                .map(ClienteResponseDTO::fromEntity)
                .toList();
    }

    @Transactional(readOnly = true)
    public ClienteResponseDTO buscarPorId(Long id) {
        ClienteEntity c = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente", id));
        return ClienteResponseDTO.fromEntity(c);
    }

    @Transactional
    public ClienteResponseDTO salvar(ClienteRequestDTO dto) {
        // Se ja existe um cliente com esse CPF/CNPJ, verificar o status
        var existente = repository.findByCpfCnpj(dto.getCpfCnpj()).orElse(null);
        if (existente != null) {
            if ("INATIVO".equalsIgnoreCase(existente.getStatusCliente())) {
                // Cliente foi inativado antes — reativa e atualiza os dados
                throw new BusinessException(
                    "Ja existe um cliente inativo com este CPF/CNPJ (ID " + existente.getId() + "). " +
                    "Use a opcao de reativar em vez de cadastrar de novo."
                );
            }
            throw new BusinessException("CPF/CNPJ ja cadastrado: " + dto.getCpfCnpj());
        }
        validarPrincipais(dto);

        ClienteEntity c = new ClienteEntity();
        c.setStatusCliente("ATIVO");
        c.setNome(dto.getNome());
        c.setCpfCnpj(dto.getCpfCnpj());
        c.setRg(dto.getRg());
        c.setEndereco(dto.getEndereco());

        // Adicionar emails e telefones
        for (ClienteEmailDTO eDto : dto.getEmails()) {
            ClienteEmailEntity e = new ClienteEmailEntity();
            e.setEmail(eDto.getEmail());
            e.setPrincipal(Boolean.TRUE.equals(eDto.getPrincipal()));
            e.setCliente(c);
            c.getEmails().add(e);
        }
        for (ClienteTelefoneDTO tDto : dto.getTelefones()) {
            ClienteTelefoneEntity t = new ClienteTelefoneEntity();
            t.setTelefone(tDto.getTelefone());
            t.setTipo(tDto.getTipo());
            t.setPrincipal(Boolean.TRUE.equals(tDto.getPrincipal()));
            t.setCliente(c);
            c.getTelefones().add(t);
        }

        return ClienteResponseDTO.fromEntity(repository.save(c));
    }

    @Transactional
    public ClienteResponseDTO atualizar(Long id, ClienteRequestDTO dto) {
        ClienteEntity c = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente", id));

        repository.findByCpfCnpj(dto.getCpfCnpj()).ifPresent(outro -> {
            if (!outro.getId().equals(id)) {
                throw new BusinessException("CPF/CNPJ ja cadastrado em outro cliente.");
            }
        });
        validarPrincipais(dto);

        c.setNome(dto.getNome());
        c.setCpfCnpj(dto.getCpfCnpj());
        c.setRg(dto.getRg());
        c.setEndereco(dto.getEndereco());

        // Substituir emails e telefones. orphanRemoval=true cuida de remover
        // os antigos automaticamente quando limpamos a colecao.
        c.getEmails().clear();
        for (ClienteEmailDTO eDto : dto.getEmails()) {
            ClienteEmailEntity e = new ClienteEmailEntity();
            e.setEmail(eDto.getEmail());
            e.setPrincipal(Boolean.TRUE.equals(eDto.getPrincipal()));
            e.setCliente(c);
            c.getEmails().add(e);
        }

        c.getTelefones().clear();
        for (ClienteTelefoneDTO tDto : dto.getTelefones()) {
            ClienteTelefoneEntity t = new ClienteTelefoneEntity();
            t.setTelefone(tDto.getTelefone());
            t.setTipo(tDto.getTipo());
            t.setPrincipal(Boolean.TRUE.equals(tDto.getPrincipal()));
            t.setCliente(c);
            c.getTelefones().add(t);
        }

        return ClienteResponseDTO.fromEntity(repository.save(c));
    }

    @Transactional
    public void deletar(Long id) {
        ClienteEntity cliente = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Cliente", id));

        // Regra: preserva historico financeiro
        if (ordemServicoRepository.existsByClienteIdAndStatusIgnoreCaseIn(id, STATUS_FINALIZADOS)) {
            throw new BusinessException(
                "Nao e possivel inativar este cliente: ele tem Ordens de Servico " +
                "CONCLUIDAS ou ENTREGUES (historico financeiro). " +
                "Mantenha o cadastro para preservar o historico."
            );
        }

        // SOFT DELETE: em vez de apagar o registro, marca como INATIVO.
        // O cliente some das listagens mas continua no banco (historico preservado).
        // As OSs em aberto e setups sao apagados pois nao tem mais utilidade.
        ordemServicoRepository.findByClienteId(id)
            .forEach(os -> ordemServicoRepository.delete(os));
        setupRepository.findByClienteId(id)
            .forEach(s -> setupRepository.delete(s));

        cliente.setStatusCliente("INATIVO");
        repository.save(cliente);
    }

    /**
     * Reativa um cliente que foi inativado (soft delete).
     */
    @Transactional
    public ClienteResponseDTO reativar(Long id) {
        ClienteEntity cliente = repository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Cliente", id));
        cliente.setStatusCliente("ATIVO");
        return ClienteResponseDTO.fromEntity(repository.save(cliente));
    }

    /**
     * Lista os clientes INATIVOS (pra tela de "lixeira"/reativacao).
     */
    @Transactional(readOnly = true)
    public List<ClienteResponseDTO> listarInativos() {
        return repository.findByStatusClienteIgnoreCase("INATIVO").stream()
                .map(ClienteResponseDTO::fromEntity)
                .toList();
    }

    /**
     * Garante que existe exatamente 1 email e 1 telefone marcado como principal.
     */
    private void validarPrincipais(ClienteRequestDTO dto) {
        long emailsPrincipais = dto.getEmails().stream()
            .filter(e -> Boolean.TRUE.equals(e.getPrincipal()))
            .count();
        if (emailsPrincipais != 1) {
            throw new BusinessException(
                "Deve haver exatamente 1 email marcado como principal (encontrei "
                + emailsPrincipais + ")."
            );
        }

        long telefonesPrincipais = dto.getTelefones().stream()
            .filter(t -> Boolean.TRUE.equals(t.getPrincipal()))
            .count();
        if (telefonesPrincipais != 1) {
            throw new BusinessException(
                "Deve haver exatamente 1 telefone marcado como principal (encontrei "
                + telefonesPrincipais + ")."
            );
        }
    }
}
