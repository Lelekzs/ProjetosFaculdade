package com.hardsoft.sistema.dtos;

import com.hardsoft.sistema.entities.AdminEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Dados devolvidos apos um login bem-sucedido.
 * NUNCA inclui a senha.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponseDTO {

    private Long id;
    private String nome;
    private String email;
    private String cargo;

    public static LoginResponseDTO fromEntity(AdminEntity a) {
        return new LoginResponseDTO(
            a.getId(),
            a.getNome(),
            a.getEmail(),
            a.getCargo()
        );
    }
}
