package com.hardsoft.sistema.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hardsoft.sistema.entities.OrdemServicoEntity;

@Repository
public interface OrdemServicoRepository extends JpaRepository<OrdemServicoEntity, Long> {

    List<OrdemServicoEntity> findByClienteId(Long clienteId);

    List<OrdemServicoEntity> findByAdminId(Long adminId);

    List<OrdemServicoEntity> findBySetupIdSetup(Long idSetup);

    List<OrdemServicoEntity> findByStatusIgnoreCase(String status);

    // Para validacoes de exclusao
    boolean existsByClienteId(Long clienteId);
    boolean existsByAdminId(Long adminId);
    boolean existsBySetupIdSetup(Long idSetup);

    // Para validar exclusao com preservacao de historico:
    // bloqueia se houver OS CONCLUIDA ou ENTREGUE
    boolean existsByClienteIdAndStatusIgnoreCaseIn(Long clienteId, List<String> statuses);
    boolean existsByAdminIdAndStatusIgnoreCaseIn(Long adminId, List<String> statuses);
}
