package com.hardsoft.sistema.entities;

public enum TipoTelefone {
    CELULAR,
    FIXO,
    COMERCIAL
}
